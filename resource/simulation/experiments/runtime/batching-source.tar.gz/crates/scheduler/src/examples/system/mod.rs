//! Inss system

use std::{collections::HashMap, sync::Arc};

use ::compute_node::ComputeNode;
use tokio::task::JoinHandle;
use tokio_util::sync::CancellationToken;
use tracing::{error, instrument, trace};

use super::scheduler::{InssScheduleSystem, InssScheduler, ModelName};

mod config;

mod listener;

pub mod compute_node;
mod task_analyzer;

pub use config::Config;
use worker::model::tensor::DynTensor;

use super::system::{
    compute_node::{
        InssComputeNode, Work,
        task::{AlreadyInferred, WaitForInference},
    },
    task_analyzer::AnalyzerHandle,
};
use crate::{SchedulableSystem, Scheduler};

/// Inss schedulable system
pub struct System {
    compute_node: Arc<InssComputeNode>,
    analyzer_handle: AnalyzerHandle,
    _schedule_handle: ScheduleHandle,
}

impl System {
    /// Init [System]
    pub fn new(
        scheduler: InssScheduler,
        compute_node: InssComputeNode,

        workload_req: HashMap<ModelName, f64>,
    ) -> Self {
        let compute_node = Arc::new(compute_node);

        let analyzer_handle = {
            let task_analyzer = task_analyzer::TaskAnalyzer::new(workload_req.clone(), 0.3);
            task_analyzer.spawn(500)
        };

        let _schedule_handle = {
            let schedulable_system = InssScheduleSystem::new(
                compute_node.clone(),
                analyzer_handle.subscribe_workload_req(),
            );

            ScheduleHandle::new(500, schedulable_system, scheduler)
        };

        Self {
            compute_node,
            analyzer_handle,
            _schedule_handle,
        }
    }

    /// Require to compute some task
    pub async fn compute(
        &self,
        model_name: ModelName,
        data: DynTensor,
    ) -> Result<Work<AlreadyInferred>, String> {
        self.analyzer_handle
            .task_arrive(&model_name, data.dimensions()[0] as usize);
        let work = Work::<WaitForInference>::new(model_name, data);
        self.compute_node.compute(work).await
    }
}

struct ScheduleHandle {
    _handle: JoinHandle<()>,
    token: CancellationToken,
}

impl ScheduleHandle {
    #[instrument(level = "trace", skip_all)]
    async fn schedule_task(
        token: CancellationToken,
        slot: u32,
        schedule_system: InssScheduleSystem,
        scheduler: InssScheduler,
    ) {
        let mut interval = tokio::time::interval(tokio::time::Duration::from_millis(slot as u64));
        loop {
            tokio::select! {
                _ = token.cancelled() => {
                    break;
                }
                _ = interval.tick() => {}
            }
            trace!("Query context");
            let context = schedule_system.query_context().await;
            trace!("Query context done");
            trace!("Schedule task");
            if let Ok(commands) = scheduler.schedule(&context).await {
                trace!("Schedule task done");
                trace!("Execute commands");
                let commands = commands.into_iter().collect::<Vec<_>>();
                // TODO: log error
                let _ = schedule_system.execute_commands(commands).await;
                trace!("Execute commands done");
            } else {
                error!("Failed to get commands from scheduler, schedule task exit!!!");
                todo!("log error")
            }
        }
    }

    fn new(slot: u32, schedule_system: InssScheduleSystem, scheduler: InssScheduler) -> Self {
        let token = CancellationToken::new();
        let _handle = tokio::spawn({
            let token = token.clone();
            async move {
                Self::schedule_task(token, slot, schedule_system, scheduler).await;
            }
        });

        Self { _handle, token }
    }
}

impl Drop for ScheduleHandle {
    fn drop(&mut self) {
        self.token.cancel();
    }
}
