//! [Adapter] provide `Replace` Command and handle uuid to gpu logical id map

use std::{
    collections::{HashMap, HashSet},
    pin::Pin,
    sync::Arc,
};

use compute_node::{
    ComputeNode,
    compute_node::virtual_util::{ComputeNodeBaseWork, ComputeNodeCommand, ComputeNodeWork},
    util::Input,
};
use futures::future::TryJoinAll;
use uuid::Uuid;

use crate::examples::{
    NvVirtualComputeNode,
    scheduler::{GpuId, ModelName, Percentage},
    system::compute_node::create_channel_map_for_each_model,
};

/// [NvVirtualComputeNode] Adapter
///
/// This struct provider ComputeNode Worker init and other useful methods such as worker id subscribe
pub struct Adapter {
    /// inner compute node
    compute_node: Arc<NvVirtualComputeNode>,
    /// GPU logical id -> GPU id
    device_logical_id: HashMap<GpuId, Uuid>,
    #[allow(clippy::type_complexity)]
    /// model name -> (worker id, gpu id, percentage) channel
    model_worker_channel: HashMap<
        ModelName,
        (
            tokio::sync::watch::Sender<(Uuid, GpuId, Percentage)>,
            tokio::sync::watch::Receiver<(Uuid, GpuId, Percentage)>,
        ),
    >,
}

/// Init
impl Adapter {
    /// Init Adapter
    #[tracing::instrument(level = "trace", skip(compute_node))]
    pub async fn init(
        compute_node: NvVirtualComputeNode,
        worker_init_command: HashMap<ModelName, (GpuId, Percentage)>,
    ) -> Result<Self, String> {
        let device_logical_id: HashMap<_, _> = compute_node
            .device_logical_id_map()
            .iter()
            .map(|(id, logical_id)| (*logical_id as usize, *id))
            .collect();
        let models = worker_init_command.keys().cloned().collect::<HashSet<_>>();
        assert_eq!(models.len(), worker_init_command.len());

        let model_name_worker_id_map = worker_init_command
            .into_iter()
            .map(|(model_name, (gpu_id, params))| {
                let compute_node = &compute_node;
                let device_logical_id = &device_logical_id;
                async move {
                    let id = Uuid::new_v4();
                    let create_command = ComputeNodeCommand::CreateWorker {
                        id,
                        device_id: device_logical_id[&gpu_id],
                        params,
                    };
                    let load_command = ComputeNodeCommand::LoadModel {
                        id,
                        name: model_name.clone(),
                    };

                    compute_node.handle(create_command).await?;
                    compute_node.handle(load_command).await?;

                    Ok::<(String, (Uuid, GpuId, Percentage)), String>((
                        model_name,
                        (id, gpu_id, params),
                    ))
                }
            })
            .collect::<TryJoinAll<_>>()
            .await?;

        let model_worker_channel = create_channel_map_for_each_model(model_name_worker_id_map);

        Ok(Self {
            compute_node: Arc::new(compute_node),
            device_logical_id,
            model_worker_channel,
        })
    }
}

/// 代理方法
impl Adapter {
    /// return a function that can be used to compute
    #[allow(clippy::type_complexity)]
    pub fn compute(
        &self,
        model_name: impl AsRef<str>,
    ) -> impl Fn(
        ComputeNodeBaseWork<Input>,
    ) -> Pin<
        Box<
            dyn Future<Output = Result<<NvVirtualComputeNode as ComputeNode>::OutputData, String>>
                + Send,
        >,
    > + Clone
    + Send
    + Sync
    + 'static {
        // Can't avoid use Box here as rust not support impl Fn() -> impl Future now,
        // it will be possible when AsyncFn support mark CallRefFuture as Send [Return type notation-style bounds for async closures](https://github.com/rust-lang/rust/pull/132706) in the future
        let compute_node = self.compute_node.clone();
        let worker_id_rx = self.subscribe_worker_state(model_name);
        move |work| {
            let compute_node = compute_node.clone();
            Box::into_pin(Box::new({
                let worker_id_rx = worker_id_rx.clone();
                async move {
                    let target_worker = worker_id_rx.borrow().0;
                    let work = ComputeNodeWork {
                        work,
                        target_worker,
                    };
                    compute_node.compute(work).await
                }
            }))
        }
    }

    /// Get the inner compute node state
    pub async fn state(&self) -> Result<<NvVirtualComputeNode as ComputeNode>::State, String> {
        self.compute_node.state().await
    }

    /// Get the inner compute node status
    pub async fn status(&self) -> Result<<NvVirtualComputeNode as ComputeNode>::Status, String> {
        self.compute_node.status().await
    }

    /// Re-place model to specific gpu with target percentage
    pub async fn replace_model(
        &self,
        model_name: ModelName,
        gpu_id: GpuId,
        percentage: Percentage,
    ) -> Result<(), String> {
        //TODO: more efficient way to replace model
        let new_worker_id = Uuid::new_v4();
        let create_command = ComputeNodeCommand::CreateWorker {
            id: new_worker_id,
            device_id: self.device_logical_id[&gpu_id],
            params: percentage,
        };
        let load_command = ComputeNodeCommand::LoadModel {
            id: new_worker_id,
            name: model_name.clone(),
        };
        let destroy_command = ComputeNodeCommand::DestroyWorker {
            id: self.model_worker_channel[&model_name].1.borrow().0,
        };

        self.compute_node
            .handle(create_command)
            .await
            .expect("ComputeNodeCommand::CreateWorker: failed");
        self.compute_node
            .handle(load_command)
            .await
            .expect("ComputeNodeCommand::LoadModel: failed");
        self.model_worker_channel[&model_name]
            .0
            .send_replace((new_worker_id, gpu_id, percentage));
        tokio::spawn({
            let compute_node = self.compute_node.clone();
            async move {
                let _ = compute_node.handle(destroy_command).await;
            }
        });
        Ok(())
    }
}

impl Adapter {
    /// Get the device id map
    pub fn device_id(&self) -> HashMap<Uuid, GpuId> {
        self.compute_node
            .device_logical_id_map()
            .iter()
            .map(|(gpu_id, id)| (*gpu_id, *id as GpuId))
            .collect()
    }

    /// subscribe specific model worker id change
    pub fn subscribe_worker_state(
        &self,
        model_name: impl AsRef<str>,
    ) -> tokio::sync::watch::Receiver<(Uuid, GpuId, Percentage)> {
        self.model_worker_channel[model_name.as_ref()].1.clone()
    }

    /// Get the model placements
    pub fn get_model_placements(&self) -> HashMap<ModelName, (GpuId, Percentage)> {
        self.model_worker_channel
            .iter()
            .map(|(model_name, (_, receiver))| {
                let (_, gpu_id, percentage) = *receiver.borrow();
                (model_name.clone(), (gpu_id, percentage))
            })
            .collect()
    }
}
