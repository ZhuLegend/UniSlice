//! Analyzer of inference task

use std::{
    collections::HashMap,
    sync::{Arc, Mutex},
};

use tokio_util::sync::CancellationToken;

use crate::examples::scheduler::ModelName;

pub struct TaskAnalyzer {
    /// task num in a time slot, model name -> task num
    task_slot: HashMap<ModelName, Mutex<usize>>,
    /// moving average of the request rate, model name -> request rate
    workload_req: HashMap<ModelName, Mutex<f64>>,
    adjust_rate: f64,
}

impl TaskAnalyzer {
    /// Create a new TaskAnalyzer
    ///
    /// # Arguments
    /// * `workload_req` - The initial request rate for each model
    /// * `slot` - The number of slots to be used
    #[tracing::instrument(level = "debug")]
    pub fn new(workload_req: HashMap<ModelName, f64>, adjust_rate: f64) -> Self {
        let task_slot = workload_req
            .keys()
            .map(|k| (k.clone(), Mutex::new(0)))
            .collect();
        let workload_req = workload_req
            .into_iter()
            .map(|(k, v)| (k, Mutex::new(v)))
            .collect();

        Self {
            task_slot,
            workload_req,
            adjust_rate,
        }
    }

    fn task_arrive(&self, model_name: impl AsRef<str>, num: usize) {
        let mut task_num = self.task_slot[model_name.as_ref()].lock().unwrap();
        *task_num += num;
    }

    fn update_req(&self) -> HashMap<ModelName, f64> {
        let adjust_rate = self.adjust_rate;
        self.task_slot
            .iter()
            .map(|(model_name, task_num)| {
                let mut workload_req = self.workload_req[model_name].lock().unwrap();
                let task_num = *task_num.lock().unwrap();
                let curr_req = *workload_req;
                let req_rate = task_num as f64 / adjust_rate;

                *workload_req = adjust_rate * req_rate + (1.0 - adjust_rate) * curr_req;
                (model_name.clone(), task_num as f64)
            })
            .collect()
    }

    fn get_workload_req(&self) -> HashMap<ModelName, f64> {
        self.workload_req
            .iter()
            .map(|(k, v)| (k.clone(), *v.lock().unwrap()))
            .collect()
    }

    pub fn spawn(self, slot: u32) -> AnalyzerHandle {
        AnalyzerHandle::new(self, slot)
    }
}

pub struct AnalyzerHandle {
    analyzer: Arc<TaskAnalyzer>,
    _handler: tokio::task::JoinHandle<()>,
    #[allow(clippy::type_complexity)]
    workload_req_channel: (
        tokio::sync::watch::Sender<HashMap<ModelName, f64>>,
        tokio::sync::watch::Receiver<HashMap<ModelName, f64>>,
    ),
    token: CancellationToken,
}

impl AnalyzerHandle {
    fn new(analyzer: TaskAnalyzer, slot: u32) -> Self {
        let token = CancellationToken::new();
        let analyzer = Arc::new(analyzer);
        let workload_req_channel = tokio::sync::watch::channel(analyzer.get_workload_req());
        let _handler = {
            let token = token.clone();
            let analyzer = analyzer.clone();
            let tx = workload_req_channel.0.clone();
            tokio::spawn(async move {
                let mut interval =
                    tokio::time::interval(tokio::time::Duration::from_millis(slot as u64));
                loop {
                    tokio::select! {
                        _ = token.cancelled() => {
                            break;
                        }
                        _ = interval.tick() => {}
                    }
                    tokio::spawn({
                        let analyzer = analyzer.clone();
                        let tx = tx.clone();
                        async move {
                            let task_req = analyzer.update_req();
                            tx.send_replace(task_req);
                        }
                    });
                }
            })
        };

        Self {
            analyzer,
            _handler,
            token,
            workload_req_channel,
        }
    }

    pub fn task_arrive(&self, model_name: impl AsRef<str>, num: usize) {
        self.analyzer.task_arrive(model_name, num);
    }

    pub fn subscribe_workload_req(&self) -> tokio::sync::watch::Receiver<HashMap<ModelName, f64>> {
        self.workload_req_channel.1.clone()
    }
}

impl Drop for AnalyzerHandle {
    fn drop(&mut self) {
        self.token.cancel();
    }
}
