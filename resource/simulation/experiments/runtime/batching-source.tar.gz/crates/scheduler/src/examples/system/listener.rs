use comm::Listener;
use worker::model::tensor::DynTensor;

use crate::examples::{
    scheduler::ModelName,
    system::{System, compute_node::Work},
};

impl Listener for System {
    type Request = (ModelName, DynTensor);
    type Response = Option<DynTensor>;

    #[tracing::instrument(level = "warn", skip(self))]
    async fn on_connect_error(&self, e: std::io::Error) {
        tracing::warn!("Connection error: {}", e);
    }

    #[tracing::instrument(level = "warn", skip(self))]
    async fn on_channel_error(&self, e: comm::CommError) {
        tracing::warn!("Channel error: {}", e);
    }

    #[tracing::instrument(level = "trace", skip(self))]
    async fn on_recv_frame(&self, (model_name, tensor): Self::Request) -> Self::Response {
        self.compute(model_name, tensor)
            .await
            .ok()
            .map(Work::extract_tensor)
    }
}
