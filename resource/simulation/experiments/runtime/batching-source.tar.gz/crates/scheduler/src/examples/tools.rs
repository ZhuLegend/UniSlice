//! Utility functions for the Inss System.

use super::MsTimestamp;

pub(super) fn get_curr_ms() -> MsTimestamp {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .expect("System time before UNIX EPOCH")
        .as_millis() as u64
}
