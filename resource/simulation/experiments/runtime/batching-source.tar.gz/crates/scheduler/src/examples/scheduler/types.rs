/// GPU Id
pub type GpuId = usize;
/// GPU type
pub type GpuType = String;
/// Model Id
pub type ModelId = usize;
/// Model Name
pub type ModelName = String;
/// Batch Size
pub type BatchSize = usize;
/// Resource Slices
pub type ResourceSlices = usize;
/// Percentage
pub type Percentage = u32;
