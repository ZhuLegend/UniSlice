//! Module containing sharing code for examples in the scheduler crate.

use compute_node::{
    compute_device::nv::vgpu::mps::NvidiaMpsShareableGpu,
    compute_node::{nv::NvMpsVirtualGpuWorkerProxy, virtual_util::GeneralVirtualComputeNode},
};
use worker::torch::worker::TorchWorker;

pub mod scheduler;
pub mod system;
pub mod tools;

/// The type of the timestamp used in the system.
pub type MsTimestamp = u64;

type NvVirtualComputeNode =
    GeneralVirtualComputeNode<TorchWorker, NvidiaMpsShareableGpu, NvMpsVirtualGpuWorkerProxy>;
