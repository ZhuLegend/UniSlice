use serde::{Deserialize, Serialize};

use crate::examples::{
    MsTimestamp,
    scheduler::BatchSize,
    system::compute_node::task::{AlreadyInferred, BatchedTask, Task, WaitForInference},
};

/// The state of the task handler.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TaskHandlerState {
    /// Current length of the task queue.
    pub wait_task_len: usize,
    /// The maximum wait time of the task queue.
    pub max_wait_time: MsTimestamp,
}

/// The task handler is responsible for batching tasks and sending them to the inference function.
#[derive(Debug)]
pub struct TaskHandler {
    _handle: tokio::task::JoinHandle<()>,
    token: tokio_util::sync::CancellationToken,
    task_tx: tokio::sync::mpsc::Sender<Task<WaitForInference>>,
    task_state_watcher: tokio::sync::watch::Receiver<TaskHandlerState>,
}

impl TaskHandler {
    fn take_target_size_tasks(
        task_buffer: &mut Vec<Task<WaitForInference>>,
        target: BatchSize,
    ) -> Option<BatchedTask<WaitForInference>> {
        let position = task_buffer
            .iter()
            .scan(0, |state, x| {
                *state += x.info.batch_size;
                Some(*state)
            })
            .position(|sum| sum >= target)?;

        Some(task_buffer.drain(..=position).collect())
    }

    /// Creates a new [TaskHandler].
    pub fn new<
        Fut: Future<Output = Result<BatchedTask<AlreadyInferred>, String>> + Send + 'static,
    >(
        mut batch_size: tokio::sync::watch::Receiver<BatchSize>,
        inference_fn: impl Fn(BatchedTask<WaitForInference>) -> Fut + Clone + Send + Sync + 'static,
    ) -> Self {
        let token = tokio_util::sync::CancellationToken::new();
        // 32 is max batch size in inference
        let (task_tx, mut task_rx) = tokio::sync::mpsc::channel::<Task<WaitForInference>>(32);
        let (state_tx, state_rx) = tokio::sync::watch::channel(TaskHandlerState {
            wait_task_len: 0,
            max_wait_time: 0,
        });
        let _handle = {
            let token = token.clone();
            let mut task_buffer: Vec<Task<WaitForInference>> = Vec::new();
            tokio::spawn(async move {
                loop {
                    tokio::select! {
                        _ = batch_size.changed() => {},
                        task = task_rx.recv() => {
                            if let Some(task) = task {
                                let batch_size = task.info.batch_size;
                                task_buffer.push(task);
                                state_tx.send_modify(|state| {
                                    state.wait_task_len += batch_size;
                                })
                            }
                        }
                        _ = token.cancelled() => {
                            break;
                        }
                    }
                    let batch_size = *batch_size.borrow();

                    if let Some(batched_task) =
                        Self::take_target_size_tasks(&mut task_buffer, batch_size)
                    {
                        state_tx.send_modify(|state| {
                            state.wait_task_len -= batched_task.batch_size();
                            state.max_wait_time = task_buffer
                                .first()
                                .map(|task| task.info.received_time)
                                .unwrap_or(0);
                        });
                        {
                            let inference_fn = inference_fn.clone();
                            tokio::spawn(async move {
                                if let Ok(res) = inference_fn(batched_task).await {
                                    res.split()
                                        .into_iter()
                                        .for_each(Task::<AlreadyInferred>::response);
                                }
                            });
                        }
                    }
                }
            })
        };
        Self {
            _handle,
            token,
            task_tx,
            task_state_watcher: state_rx,
        }
    }

    /// Submit a task to the task handler.
    pub async fn submit(&self, task: Task<WaitForInference>) -> Result<(), String> {
        self.task_tx
            .send(task)
            .await
            .map_err(|_| "send task failed".to_string())
    }

    /// A watcher for the task handler state.
    pub fn subscribe_state(&self) -> tokio::sync::watch::Receiver<TaskHandlerState> {
        self.task_state_watcher.clone()
    }
}

impl Drop for TaskHandler {
    fn drop(&mut self) {
        self.token.cancel();
    }
}
