use std::collections::HashMap;

use compute_node::ComputeNode;

use crate::{
    SchedulableSystem, Scheduler,
    examples::scheduler::{BatchSize, GpuId, InssScheduler, ModelId, ResourceSlices},
};

impl InssScheduler {
    /// Get the model id that needs to be changed
    fn get_change_required_model(
        current_states: &HashMap<ModelId, (GpuId, ResourceSlices, BatchSize)>,
        decision: &HashMap<ModelId, (GpuId, ResourceSlices, BatchSize)>,
    ) -> Vec<ModelId> {
        decision
            .iter()
            .filter_map(|(model_id, (gpu_id, resource_slices, _))| {
                if let Some((current_gpu_id, current_resource_slices, _)) =
                    current_states.get(model_id)
                {
                    if gpu_id != current_gpu_id || resource_slices != current_resource_slices {
                        Some(*model_id)
                    } else {
                        None
                    }
                } else {
                    Some(*model_id)
                }
            })
            .collect()
    }

    /// Generate compute node commands from decisions
    #[allow(clippy::type_complexity)]
    pub fn generate_compute_node_commands(
        &self,
        _context: &<<Self as Scheduler>::System as SchedulableSystem>::Context,
        current_states: &HashMap<ModelId, (GpuId, ResourceSlices, BatchSize)>,
        decision: &HashMap<ModelId, (GpuId, ResourceSlices, BatchSize)>,
    ) -> impl IntoIterator<
        Item = <<<Self as Scheduler>::System as SchedulableSystem>::ComputeNode as ComputeNode>::Command,
    >{
        let change_required_models = Self::get_change_required_model(current_states, decision);

        change_required_models
            .iter()
            .filter_map(|model_id| {
                let (gpu_id, resource_slices, batch_size) = decision.get(model_id)?;
                let model_name = self.environment.model_type_list[*model_id].clone();
                let gpu_id = *gpu_id;
                let resource_slices = *resource_slices;
                let percentage = self.environment.slice_to_percentage(
                    self.environment.gpu_type_list[gpu_id].as_str(),
                    resource_slices,
                );
                let batch_size = *batch_size;

                Some([
                    crate::examples::system::compute_node::Command::SetModelPlace(
                        model_name.clone(),
                        gpu_id,
                        percentage,
                    ),
                    crate::examples::system::compute_node::Command::SetBatchSize(
                        model_name, batch_size,
                    ),
                ])
            })
            .flatten()
            .collect::<Vec<_>>()
    }
}
