use std::{collections::HashMap, ops::Deref, sync::Arc};

use compute_node::ComputeNode;
use futures::future::TryJoinAll;
use tracing::{error, trace};
use worker::model::{model::InferenceModel, tensor::Tensor};

use super::{BatchSize, GpuId, InssScheduler, ModelId, ModelName, Status};
use crate::{SchedulableSystem, Scheduler, examples::system::compute_node::InssComputeNode};

mod commands;
mod percentage_helper;

/// Scheduler context
#[derive(Debug)]
pub struct InssScheduleContext {
    /// System status
    pub status: Status,
    /// Model placements, model name -> (gpu id, percentage)
    pub model_placements: HashMap<ModelName, (GpuId, u32)>,
    /// Batch size, model name -> batch size
    pub batch_size: HashMap<ModelName, BatchSize>,
}

impl InssScheduleContext {
    /// Get GPU deployment
    ///
    /// # Parameters
    /// - model_id_querier: A function that takes a model name and returns the Option<model id>
    ///
    /// # Returns
    /// model id -> GPU id
    fn get_model_deployment(
        &self,
        model_id_map: impl Fn(&str) -> ModelId,
    ) -> HashMap<ModelId, GpuId> {
        self.model_placements
            .iter()
            .map(|(model_name, (gpu_id, _))| {
                let model_id = model_id_map(model_name);
                (model_id, *gpu_id)
            })
            .collect()
    }
}

/// Scheduler system
pub struct InssScheduleSystem {
    compute_node: Arc<InssComputeNode>,
    /// Workload request rate, model name -> workload request rate (1/s)
    workload_req_rx: tokio::sync::watch::Receiver<HashMap<ModelName, f64>>,
    /// Model name -> model id
    model_id_map: HashMap<ModelName, ModelId>,
}

impl InssScheduleSystem {
    /// Create a new InssScheduleSystem
    ///
    /// # Arguments
    ///
    /// - `workload_infos_getter` - A function that returns a future that resolves to a map of device id to workload request rate
    pub fn new(
        compute_node: Arc<InssComputeNode>,
        workload_req_rx: tokio::sync::watch::Receiver<HashMap<ModelName, f64>>,
    ) -> Self {
        let models = compute_node.models();
        let model_id_map = models
            .iter()
            .enumerate()
            .map(|(id, model_name)| (model_name.clone(), id as ModelId))
            .collect();

        Self {
            compute_node,
            workload_req_rx,
            model_id_map,
        }
    }
}

impl SchedulableSystem for InssScheduleSystem {
    type ComputeNodeID = ();
    type ComputeNode = InssComputeNode;
    type Context = InssScheduleContext;
    type Error = String;

    async fn query_context(&self) -> Self::Context {
        let crate::examples::system::compute_node::State {
            model_placements,
            batch_size,
        } = self.compute_node.state().await.unwrap();
        let crate::examples::system::compute_node::Status {
            gpu_state,
            buffer_state,
        } = self.compute_node.status().await.unwrap();

        let (workload, workload_wait_time) = buffer_state.into_iter().fold(
            (
                HashMap::with_capacity(model_placements.len()),
                HashMap::with_capacity(model_placements.len()),
            ),
            |(mut workload, mut workload_wait_time),
             (model_name, (wait_queue_len, max_wait_time))| {
                let model_id = self.model_id_map[&model_name];
                workload.insert(model_id, wait_queue_len as f32 / 100.0);
                workload_wait_time.insert(model_id, max_wait_time as f32);
                (workload, workload_wait_time)
            },
        );

        InssScheduleContext {
            status: Status {
                gpu_status: gpu_state,
                workload_req: self
                    .workload_req_rx
                    .borrow()
                    .clone()
                    .into_iter()
                    .map(|(model_name, rate)| {
                        let model_id = self.model_id_map[&model_name];
                        (model_id, rate as f32 / 100.0)
                    })
                    .collect(),
                workload,
                workload_wait_time,
            },
            model_placements,
            batch_size,
        }
    }

    async fn execute_commands<
        I: IntoIterator<
                Item = (
                    Self::ComputeNodeID,
                    Vec<<<Self as SchedulableSystem>::ComputeNode as ComputeNode>::Command>,
                ),
            > + Send,
    >(
        &self,
        command_pairs: I,
    ) -> Result<(), Self::Error> {
        command_pairs
            .into_iter()
            .flat_map(|(_, commands)| commands)
            .map(|command| self.compute_node.handle(command))
            .collect::<TryJoinAll<_>>()
            .await?;

        Ok(())
    }
}

impl Scheduler for InssScheduler {
    type System = InssScheduleSystem;
    type Error = String;

    async fn schedule(
        &self,
        context: impl Deref<Target = <Self::System as SchedulableSystem>::Context>,
    ) -> Result<
        impl IntoIterator<
            Item = (
                <Self::System as SchedulableSystem>::ComputeNodeID,
                Vec<<<Self::System as SchedulableSystem>::ComputeNode as ComputeNode>::Command>,
            ),
        >,
        Self::Error,
    > {
        let context = context.deref();
        let model_deploy = context.get_model_deployment(|model_name| {
            self.environment
                .model_type_list
                .iter()
                .position(|item| item == model_name)
                .unwrap()
        });

        let InssScheduleContext {
            status,
            model_placements,
            batch_size,
        } = context;

        let input_tensor = self.extract_input_dim(status, &model_deploy);

        let output_tensor: Tensor<f32> = self
            .inference_model
            .forward(input_tensor)
            .await
            .map_err(|e| {
                error!("Inference model forward error: {:?}", e);
                e.to_string()
            })?
            .into();

        trace!("Output tensor dim: {:?}", output_tensor.data().shape());

        let unoptimized_decisions = self.parse_output_dim(output_tensor);
        trace!(
            "Unoptimized inference decisions: {:?}",
            unoptimized_decisions
        );
        let decisions = self.get_possible_decision(&unoptimized_decisions);
        trace!("Possible decisions: {:?}", decisions);

        let current_states = model_placements
            .iter()
            .map(|(model_name, (gpu_id, percentage))| {
                let model_id = self
                    .environment
                    .model_type_list
                    .iter()
                    .position(|item| item == model_name)
                    .unwrap();
                let batch_size = batch_size[model_name];
                let resource_slice = self.environment.percentage_to_slices(
                    self.environment.gpu_type_list[*gpu_id].as_str(),
                    *percentage,
                );
                (model_id, (*gpu_id, resource_slice, batch_size))
            })
            .collect::<HashMap<_, _>>();

        trace!("Current states: {:?}", current_states);

        let (batch_decision, _total_throughput) = self.batch_optimizer(
            &current_states,
            &{
                let mut decisions = decisions
                    .iter()
                    .map(|(model_id, (gpu_id, resource_slice))| {
                        (*model_id, (*gpu_id, *resource_slice))
                    })
                    .collect::<Vec<_>>();
                decisions.sort_by(|(model_id_1, _), (model_id_2, _)| model_id_1.cmp(model_id_2));
                decisions
            },
            status,
        );

        trace!("Batch decisions: {:?}", batch_decision);

        let decisions = decisions
            .into_iter()
            .map(|(model_id, (gpu_id, resource_slice))| {
                let batch_size = batch_decision.get(&model_id).unwrap().0;
                (model_id, (gpu_id, resource_slice, batch_size))
            })
            .collect();

        trace!("Decisions: {:?}", decisions);

        let commands = self
            .generate_compute_node_commands(context, &current_states, &decisions)
            .into_iter()
            .collect();

        trace!("Compute node commands: {:?}", commands);

        Ok(std::iter::once(((), commands)))
    }
}
