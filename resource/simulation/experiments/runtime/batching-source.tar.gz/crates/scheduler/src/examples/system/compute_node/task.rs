//! task crate provide a list of useful type and function when handling inference task

use std::marker::PhantomData;

use serde::{Deserialize, Serialize};
use uuid::Uuid;
use worker::model::tensor::DynTensor;

use crate::examples::{MsTimestamp, tools::get_curr_ms};

/// The type of the task result sender.
pub type TaskResultSender = tokio::sync::oneshot::Sender<Result<(TaskInfo, DynTensor), String>>;

/// The `TaskInfo` struct represents the information about a task.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TaskInfo {
    /// Task id
    pub id: Uuid,
    /// Task batch size
    pub batch_size: usize,
    /// Task target model name
    pub model_name: String,
    /// Task received time, in milliseconds
    pub received_time: MsTimestamp,
    /// Task schedule time (task is selected and will be sent to ComputeNode for inference), in milliseconds
    pub schedule_time: Option<MsTimestamp>,
    /// Worker inference finish time
    pub inference_finish_time: Option<MsTimestamp>,
    /// Task completion and return time, in milliseconds
    pub response_time: Option<MsTimestamp>,
}

/// The `Task` struct represents an inference task in the system.
#[derive(Debug)]
pub struct Task<State: TaskState> {
    /// Task information
    pub info: TaskInfo,
    /// When `state` is `WaitForInference`, `tensor` is the input tensor, when `state` is `AlreadyInferred`, `tensor` is the output tensor.
    tensor: DynTensor,
    result_sender: TaskResultSender,
    state: PhantomData<State>,
}

/// The `BatchedTask` struct represents a batch of tasks.
#[derive(Debug)]
pub struct BatchedTask<State: TaskState> {
    infos: Vec<TaskInfo>,
    receivers: Vec<TaskResultSender>,
    tensor: DynTensor,
    state: PhantomData<State>,
}

impl<State: TaskState> Task<State> {
    /// Creates a new `Task` instance.
    pub fn new(
        model_name: String,
        tensor: DynTensor,
        result_sender: TaskResultSender,
    ) -> Task<WaitForInference> {
        Task {
            info: TaskInfo {
                id: Uuid::new_v4(),
                batch_size: tensor.dimensions()[0] as usize,
                received_time: get_curr_ms(),
                model_name,
                schedule_time: None,
                inference_finish_time: None,
                response_time: None,
            },
            tensor,
            result_sender,
            state: PhantomData,
        }
    }
}

impl Task<AlreadyInferred> {
    /// Consume task and send the result back to the sender.
    pub fn response(self) {
        let Task {
            mut info,
            tensor,
            result_sender,
            state: _,
        } = self;

        info.response_time = Some(get_curr_ms());

        let _ = result_sender.send(Ok((info, tensor)));
    }
}

impl FromIterator<Task<WaitForInference>> for BatchedTask<WaitForInference> {
    fn from_iter<T: IntoIterator<Item = Task<WaitForInference>>>(iter: T) -> Self {
        let tasks = iter.into_iter();
        let (infos, (tensors, receivers)): (Vec<_>, (Vec<_>, Vec<_>)) = tasks
            .map(|task| (task.info, (task.tensor, task.result_sender)))
            .unzip();

        let tensor = DynTensor::concat_batch(tensors).unwrap();

        BatchedTask {
            infos,
            tensor,
            receivers,
            state: PhantomData,
        }
    }
}

impl<State: TaskState> BatchedTask<State> {
    /// get the batch size of the batched task
    pub fn batch_size(&self) -> usize {
        self.infos.iter().map(|info| info.batch_size).sum()
    }
}

impl BatchedTask<WaitForInference> {
    /// Computes the inference for the batched task using the provided compute function.
    pub async fn compute<Fut>(
        self,
        compute_fn: impl FnOnce(DynTensor) -> Fut + Send + Sync,
    ) -> Result<BatchedTask<AlreadyInferred>, String>
    where
        Fut: Future<Output = Result<DynTensor, String>>,
    {
        let mut infos = self
            .infos
            .into_iter()
            .map(|mut info| {
                info.schedule_time = Some(get_curr_ms());
                info
            })
            .collect::<Vec<_>>();

        let tensor = compute_fn(self.tensor).await?;

        infos.iter_mut().for_each(|info| {
            info.inference_finish_time = Some(get_curr_ms());
        });

        Ok(BatchedTask {
            infos,
            tensor,
            receivers: self.receivers,
            state: PhantomData,
        })
    }
}

impl BatchedTask<AlreadyInferred> {
    /// Splits the batched task into individual tasks.
    pub fn split(self) -> Vec<Task<AlreadyInferred>> {
        let batch_sizes = self.infos.iter().map(|info| info.batch_size);
        // 将batch_sizes数组转换为分割点数组，例如，当batch_sizes为[2, 3, 4]时，分割点为[2, 5, 9]
        // 这里的分割点是指在tensor的第0维上进行分割
        let mut split_points = Vec::new();
        let mut sum = 0;
        for size in batch_sizes {
            sum += size;
            split_points.push(sum);
        }
        let tensors = self.tensor.split_batch(split_points).unwrap();

        self.infos
            .into_iter()
            .zip(tensors)
            .zip(self.receivers)
            .map(|((info, tensor), result_sender)| Task {
                info,
                tensor,
                result_sender,
                state: PhantomData,
            })
            .collect()
    }
}

mod seal {
    pub trait Sealed {}
}

/// The `TaskState` trait is a sealed trait that represents the state of a task.
pub trait TaskState: seal::Sealed {}

/// The `WaitForInference` struct represents a task that is waiting for inference.
pub struct WaitForInference;

impl seal::Sealed for WaitForInference {}
impl TaskState for WaitForInference {}

/// The `AlreadyInferred` struct represents a task that has already been inferred.
pub struct AlreadyInferred;

impl seal::Sealed for AlreadyInferred {}
impl TaskState for AlreadyInferred {}
