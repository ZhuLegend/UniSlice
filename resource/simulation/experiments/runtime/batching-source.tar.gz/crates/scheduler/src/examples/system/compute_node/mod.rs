//! [InssComputeNode]

use std::{collections::HashMap, path::PathBuf, sync::Arc};

use compute_node::compute_node::virtual_util::ComputeNodeBaseWork;
use tracing::instrument;
use worker::model::tensor::DynTensor;

pub mod adapter;
pub mod task;
mod task_handler;

mod compute_node_impl;

use adapter::Adapter;
pub use compute_node_impl::{Command, State, Status, Work};

use crate::examples::{
    NvVirtualComputeNode,
    scheduler::{BatchSize, GpuId, ModelName, Percentage},
    system::compute_node::task_handler::TaskHandler,
};

/// [InssComputeNode] assemble the [NvVirtualComputeNode] and provide task batching support
pub struct InssComputeNode {
    inner: Adapter,
    /// [TaskHandler] for each model
    task_handlers: HashMap<ModelName, TaskHandler>,
    /// The models that this computes node can run.
    models: Vec<ModelName>,
    /// Model name -> batch size
    batch_size_channels: HashMap<
        ModelName,
        (
            tokio::sync::watch::Sender<BatchSize>,
            tokio::sync::watch::Receiver<BatchSize>,
        ),
    >,
}

impl InssComputeNode {
    /// Create a new [InssComputeNode]
    #[instrument(level = "trace", skip(device_ids))]
    pub async fn new(
        device_ids: impl IntoIterator<Item = impl Into<usize>>,
        model_dir: PathBuf,
        model_config_dir: PathBuf,
        bin_worker_path: PathBuf,

        init_batch_size: HashMap<ModelName, BatchSize>,
        worker_init_command: HashMap<ModelName, (GpuId, Percentage)>,
    ) -> Result<Self, String> {
        let compute_node =
            NvVirtualComputeNode::new(device_ids, model_dir, model_config_dir, bin_worker_path);
        let worker_init_command = worker_init_command.into_iter().collect::<HashMap<_, _>>();

        let inner = Adapter::init(compute_node, worker_init_command).await?;

        let models: Vec<_> = init_batch_size.keys().cloned().collect();
        let batch_size_channels = create_channel_map_for_each_model(init_batch_size);
        let task_handlers = models
            .iter()
            .map(|model_name| {
                let rx = batch_size_channels[model_name].1.clone();
                let inference_fn = {
                    let compute_fn = Arc::new(inner.compute(model_name));
                    move |task: task::BatchedTask<task::WaitForInference>| {
                        let compute_fn = compute_fn.clone();
                        async move {
                            let inference_fn = |tensor: DynTensor| async move {
                                let work = ComputeNodeBaseWork::new(Default::default(), tensor);

                                let res = compute_fn(work).await?;

                                Ok(res.work.take().1)
                            };

                            task.compute(inference_fn).await
                        }
                    }
                };
                let task_handler = TaskHandler::new(rx, inference_fn);
                (model_name.clone(), task_handler)
            })
            .collect();

        Ok(Self {
            inner,
            models,
            batch_size_channels,
            task_handlers,
        })
    }

    /// Get support models
    pub fn models(&self) -> &[ModelName] {
        &self.models
    }
}

fn create_channel_map_for_each_model<T>(
    models: impl IntoIterator<Item = (ModelName, T)>,
) -> HashMap<
    ModelName,
    (
        tokio::sync::watch::Sender<T>,
        tokio::sync::watch::Receiver<T>,
    ),
> {
    models
        .into_iter()
        .map(|(model_name, value)| {
            let (tx, rx) = tokio::sync::watch::channel(value);
            (model_name, (tx, rx))
        })
        .collect()
}
