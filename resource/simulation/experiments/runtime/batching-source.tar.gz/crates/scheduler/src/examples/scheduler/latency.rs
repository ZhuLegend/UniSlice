//! Latency prediction for Inss

use std::{borrow::Borrow, collections::HashMap, path::Path};

use serde::{Deserialize, Serialize};

use crate::examples::scheduler::{BatchSize, GpuType, ModelName, ResourceSlices};

type ScheduleTime = HashMap<ModelName, HashMap<GpuType, f64>>;

type ExecutionTime =
    HashMap<ModelName, HashMap<GpuType, HashMap<BatchSize, HashMap<ResourceSlices, f64>>>>;

type Alpha = f64;

type Beta = f64;

type CacheUtilPreParam = HashMap<ModelName, HashMap<GpuType, (Alpha, Beta)>>;

type CacheDelay = HashMap<ModelName, HashMap<GpuType, Alpha>>;

type GpuScheduleCostParam = HashMap<GpuType, (Alpha, Beta)>;

type KernelExecTime = HashMap<ModelName, HashMap<GpuType, usize>>;

/// Latency predictor
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct LatencyPredictor {
    input_size: HashMap<ModelName, usize>,
    output_size: HashMap<ModelName, usize>,
    bandwidth: HashMap<GpuType, usize>,
    schedule_time: ScheduleTime,
    execution_time: ExecutionTime,
    cache_util: CacheUtilPreParam,
    cache_delay: CacheDelay,
    gpu_schedule_cost: GpuScheduleCostParam,
    kernel: KernelExecTime,
}

impl LatencyPredictor {
    pub fn from_file(path: impl AsRef<Path>) -> Result<Self, String> {
        let reader = std::io::BufReader::new(std::fs::File::open(path).map_err(|e| e.to_string())?);
        serde_json::from_reader(reader).map_err(|e| e.to_string())
    }
}

impl LatencyPredictor {
    fn get_execution_time(
        &self,
        model_name: impl Borrow<ModelName>,
        gpu_type: impl Borrow<GpuType>,
        batch_size: BatchSize,
        resource_slices: ResourceSlices,
    ) -> f64 {
        self.execution_time
            .get(model_name.borrow())
            .and_then(|gpu_map| gpu_map.get(gpu_type.borrow()))
            .and_then(|batch_map| batch_map.get(&batch_size))
            .and_then(|slice_map| slice_map.get(&resource_slices))
            .copied()
            .unwrap_or_else(|| {
                panic!(
                    "Cannot get execution time, query param: {}, {}, {}, {}",
                    model_name.borrow(),
                    gpu_type.borrow(),
                    batch_size,
                    resource_slices
                )
            })
    }

    fn predict_execution_time(
        &self,
        model_name: impl Borrow<ModelName>,
        gpu_type: impl Borrow<GpuType>,
        batch_size: BatchSize,
        resource_slices: ResourceSlices,
    ) -> f64 {
        let execution_time = self.get_execution_time(
            model_name.borrow(),
            gpu_type.borrow(),
            batch_size,
            resource_slices,
        );

        let schedule_time = self
            .schedule_time
            .get(model_name.borrow())
            .and_then(|gpu_map| gpu_map.get(gpu_type.borrow()))
            .copied()
            .unwrap_or_else(|| {
                panic!(
                    "Cannot get schedule time, query param: {}, {}",
                    model_name.borrow(),
                    gpu_type.borrow()
                )
            });

        execution_time + schedule_time
    }

    fn predict_interference(
        &self,
        gpu_type: impl Borrow<GpuType>,
        target_model_name: impl Borrow<ModelName>,
        target_batch_size: BatchSize,
        target_resource_slices: ResourceSlices,
        colocate_model_name: impl Borrow<ModelName>,
        colocate_resource_slices: ResourceSlices,
    ) -> f64 {
        let target_execution_time = self.get_execution_time(
            target_model_name.borrow(),
            gpu_type.borrow(),
            target_batch_size,
            target_resource_slices,
        );
        let colocate_cache_util_param = self
            .cache_util
            .get(colocate_model_name.borrow())
            .and_then(|gpu_map| gpu_map.get(gpu_type.borrow()))
            .map(|(alpha, beta)| (*alpha, *beta))
            .unwrap_or_else(|| {
                panic!(
                    "Cannot get cache util param, query param: {}, {}",
                    colocate_model_name.borrow(),
                    gpu_type.borrow()
                )
            });
        let colocate_cache_util = colocate_cache_util_param.0 * colocate_resource_slices as f64
            + colocate_cache_util_param.1;

        self.cache_delay
            .get(target_model_name.borrow())
            .and_then(|gpu_map| gpu_map.get(gpu_type.borrow()))
            .copied()
            .unwrap_or_else(|| {
                panic!(
                    "Cannot get cache delay, query param: {}, {}",
                    target_model_name.borrow(),
                    gpu_type.borrow()
                )
            })
            * colocate_cache_util
            * target_execution_time
    }

    fn predict_interference_idle(
        &self,
        gpu_type: &GpuType,
        model_name: &ModelName,
        colocate_model_count: u32,
    ) -> f64 {
        let gpu_scheduling_cost_param = self
            .gpu_schedule_cost
            .get(gpu_type)
            .copied()
            .unwrap_or_else(|| {
                panic!("Cannot get gpu scheduling cost param, query param: {gpu_type}",)
            });

        let kernel_exec_time = self
            .kernel
            .get(model_name)
            .and_then(|gpu_map| gpu_map.get(gpu_type))
            .copied()
            .unwrap_or_else(|| {
                panic!("Cannot get kernel exec time, query param: {model_name}, {gpu_type}",)
            });

        (gpu_scheduling_cost_param.0 * colocate_model_count as f64 + gpu_scheduling_cost_param.1)
            * kernel_exec_time as f64
    }

    /// Predict execution latency
    ///
    /// # Returns
    /// execution latency (ms)
    pub fn predict_execution_latency(
        &self,
        gpu_type: &GpuType,
        model_name: &ModelName,
        batch_size: BatchSize,
        resource_slices: ResourceSlices,
        colocate_models: Vec<(ModelName, ResourceSlices)>,
    ) -> f64 {
        let input_transfer_time = self
            .input_size
            .get(model_name)
            .and_then(|size| {
                self.bandwidth
                    .get(gpu_type)
                    .map(|bw| *size as f64 / *bw as f64)
            })
            .unwrap_or_else(|| {
                panic!("Cannot get input transfer time, query param: {model_name}, {gpu_type}")
            });
        let output_transfer_time = self
            .output_size
            .get(model_name)
            .and_then(|size| {
                self.bandwidth
                    .get(gpu_type)
                    .map(|bw| *size as f64 / *bw as f64)
            })
            .unwrap_or_else(|| {
                panic!("Cannot get output transfer time, query param: {model_name}, {gpu_type}")
            });

        let mut latency =
            self.predict_execution_time(model_name, gpu_type, batch_size, resource_slices)
                + input_transfer_time
                + output_transfer_time;

        let colocate_model_count = colocate_models.len() as f64;

        for (colocate_model_name, colocate_resource_slices) in colocate_models {
            latency += self.predict_interference(
                gpu_type,
                model_name,
                batch_size,
                resource_slices,
                &colocate_model_name,
                colocate_resource_slices,
            );
        }

        latency +=
            self.predict_interference_idle(gpu_type, model_name, colocate_model_count as u32);

        latency
    }
}
