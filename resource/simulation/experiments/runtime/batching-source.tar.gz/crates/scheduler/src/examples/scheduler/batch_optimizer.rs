use std::collections::HashMap;

use crate::examples::scheduler::{
    BatchSize, GpuId, InssScheduler, ModelId, ResourceSlices, Status,
};

fn partial_max<T: PartialOrd>(a: T, b: T) -> T {
    if a > b { a } else { b }
}

impl Status {
    /// gpu id -> (free memory, total memory)
    fn gpu_memory(&self) -> HashMap<GpuId, (u64, u64)> {
        self.gpu_status
            .iter()
            .map(|(gpu_id, status)| {
                let (total, free, _) = status;
                (*gpu_id, (*free, *total))
            })
            .collect::<HashMap<_, _>>()
    }
}

impl InssScheduler {
    fn get_model_memory(&self, model_name: &str, gpu_id: GpuId, batch_size: BatchSize) -> f32 {
        let gpu_type = self.environment.gpu_type_list[gpu_id].as_str();

        self.model_memory_cost
            .get(model_name)
            .and_then(|gpu_map| gpu_map.get(gpu_type))
            .and_then(|batch_map| batch_map.get(&batch_size))
            .copied()
            .unwrap()
    }

    /// 判断当前batch size配置是否能让当前model满足SLO
    fn is_match_slo(
        workload_rate: f64,
        workload_wait_time: f64,
        slo: f64,
        workload: u64,
        batch_size: usize,
        inference_time: f64,
    ) -> bool {
        let mut slo_flag = true;
        let mut end_time = 0.0;
        let num = ((workload + 1) as f32 / batch_size as f32).ceil() as u64;

        for i in 0..num {
            let wait = if workload + 1 < (i + 1) * batch_size as u64 {
                ((i + 1) * batch_size as u64 - workload + 1) as f64 / workload_rate
            } else {
                0.0
            };

            let total_time = workload_wait_time
                - workload_wait_time * (i * batch_size as u64) as f64 / workload as f64
                + partial_max(end_time, wait)
                + inference_time;

            if total_time > slo {
                slo_flag = false;
                break;
            }

            end_time = partial_max(end_time, wait) + inference_time;
        }

        slo_flag
    }

    /// 求解某个特定模型部署决策所应配置的batch size
    ///
    /// # Parameters
    /// - workload: 当前等待工作负载 (个)
    /// - workload_rate: 工作负载到达速率 (个/秒)
    /// - workload_wait_time: 工作负载最长等待时间 (秒)
    /// - gpu_memory: GPU内存使用情况 (gpu id -> (free memory, total memory))
    /// - slo: 模型SLO (秒)
    /// - place_flag: 是否需要重新放置模型
    /// - pre_batch_size: 当前状态设置的batch size
    /// - execution_latency_predictor: 执行延迟预测器
    ///
    /// # Return
    /// (Option<batch size>, model memory min, model memory)
    fn optimize_batch(
        workload: u64,
        workload_rate: f64,
        workload_wait_time: f64,
        gpu_memory: &(u64, u64),
        slo: f64,
        execution_latency_predictor: impl Fn(usize) -> f64,
        model_memory_requirements_predictor: impl Fn(usize) -> (f64, f64),
    ) -> (Option<usize>, f64, f64) {
        let mut batch_temp = 0;

        let mut start = 32;
        let mut end = 1;

        let mut model_memory_min = 0.0;
        let mut model_memory = 0.0;

        while start >= end {
            let batch_size = (start + end) / 2;
            let inference_time = execution_latency_predictor(batch_size) / 1000.0;

            let throughput = (batch_size as f64 / inference_time).floor() as u64;

            let is_match_slo = Self::is_match_slo(
                workload_rate,
                workload_wait_time,
                slo,
                workload,
                batch_size,
                inference_time,
            );

            (model_memory_min, model_memory) = model_memory_requirements_predictor(batch_size);

            if !is_match_slo
                || ((gpu_memory.0 as f64) < model_memory_min)
                || ((gpu_memory.1 as f64) < model_memory)
            {
                start = batch_size - 1;
                if (throughput as f64) < workload_rate {
                    break;
                }
            } else {
                if throughput as f64 > workload_rate {
                    batch_temp = batch_size;
                }
                end = batch_size + 1;
            }
        }

        if batch_temp == 0 {
            (None, model_memory_min, model_memory)
        } else {
            (Some(batch_temp), model_memory_min, model_memory)
        }
    }

    /// 决策模型批大小
    ///
    /// # Parameters
    /// - states: 当前系统模型状态，model id -> (GPU id, resource slice, batch size)
    /// - decisions: 调度模型决策，(model id -> (GPU id, resource slice))
    /// - status: 系统状态
    ///
    /// # Returns
    /// 模型批大小设置 (model id -> (batch size, flag, duty_cycle), throughput_sum)
    pub fn batch_optimizer(
        &self,
        states: &HashMap<ModelId, (GpuId, ResourceSlices, BatchSize)>,
        decisions: &[(ModelId, (GpuId, ResourceSlices))],
        status: &Status,
    ) -> (HashMap<ModelId, (BatchSize, bool, f64)>, f64) {
        assert!(decisions.is_sorted_by(|(model_id_1, _), (model_id_2, _)| model_id_1 < model_id_2));
        assert_eq!(states.len(), decisions.len());

        let mut throuchput_sum = 0.0;
        let mut batches = states
            .iter()
            .map(|(model_id, (_, _, batch_size))| (*model_id, *batch_size))
            .collect::<HashMap<_, _>>();
        let mut duty_cycle = vec![0.0; self.model_nums as usize];
        let mut flag = vec![true; self.model_nums as usize];

        // GPU id -> (GPU内存空闲量，GPU内存总量)
        let mut gpu_memory = status.gpu_memory();

        for (model_id, (gpu_id, resource_slice)) in decisions.iter() {
            let model_name = self.environment.model_type_list.get(*model_id).unwrap();
            let place_flag = {
                let pre_state = states.get(model_id).unwrap();
                !((pre_state.0 == *gpu_id) && (pre_state.1 == *resource_slice))
            };

            let slo = *self.model_slo.get(model_name).expect("Model SLO not found") / 1000.0;

            let rate = (status
                .workload_req
                .get(model_id)
                .expect("Model workload not found")
                * 100.0) as f64;
            let workload = (status
                .workload
                .get(model_id)
                .expect("Model workload not found")
                * 100.0) as u64;

            let memory_predictor =
                |batch_size: usize| self.get_model_memory(model_name, *gpu_id, batch_size) as f64;

            let (batch_size, model_memory_min, model_memory) = Self::optimize_batch(
                if workload == 0 { 1 } else { workload },
                rate,
                *status
                    .workload_wait_time
                    .get(model_id)
                    .expect("Model workload wait time not found") as f64
                    / 1000.0,
                gpu_memory.get_mut(gpu_id).unwrap(),
                slo as f64,
                |batch_size| {
                    self.latency_predictor.predict_execution_latency(
                        &self.environment.gpu_type_list[*gpu_id],
                        model_name,
                        batch_size,
                        *resource_slice,
                        vec![],
                    )
                },
                |batch_size| {
                    let model_memory_min;
                    let model_memory;
                    if place_flag {
                        model_memory_min = memory_predictor(1);
                        model_memory = memory_predictor(batch_size);
                    } else {
                        model_memory_min = memory_predictor(batch_size)
                            - memory_predictor(states.get(model_id).unwrap().2);
                        model_memory = model_memory_min;
                    }

                    (model_memory_min, model_memory)
                },
            );

            let batch_ref = batches.get_mut(model_id).unwrap();

            if let Some(batch_temp) = batch_size {
                *batch_ref = batch_temp;
            } else {
                flag[*model_id] = false;
            }

            let gpu_memory = gpu_memory.get_mut(gpu_id).unwrap();
            gpu_memory.0 -= model_memory_min as u64;
            gpu_memory.1 -= model_memory as u64;

            let pure_exec_time = self.latency_predictor.predict_execution_latency(
                &self.environment.gpu_type_list[*gpu_id],
                model_name,
                *batch_ref,
                *resource_slice,
                vec![],
            );
            throuchput_sum += *batch_ref as f64 * 1000.0 / pure_exec_time;
            duty_cycle[*model_id] = self.model_slo[&self.environment.model_type_list[*model_id]]
                as f64
                - pure_exec_time;
        }

        let result = batches.into_iter().fold(
            HashMap::with_capacity(self.model_nums as usize),
            |mut acc, (model_id, batch_size)| {
                acc.insert(model_id, (batch_size, flag[model_id], duty_cycle[model_id]));
                acc
            },
        );

        (result, throuchput_sum)
    }
}
