//! Inss Scheduler Example

#![warn(missing_docs)]

use std::{collections::HashMap, path::Path};

use latency::LatencyPredictor;
use serde::{Deserialize, de::DeserializeOwned};
use worker::{
    model::{
        model::InferenceModel,
        tensor::{Device, TensorElementType},
    },
    torch::{TorchModel, model::TorchModelLoadConfig},
};

mod scheduler_impl;

mod batch_optimizer;
mod latency;
mod make_decision;
mod types;

pub use scheduler_impl::*;
pub use types::*;

/// Status of current system
#[derive(Debug)]
pub struct Status {
    /// GPU状态，GPU id -> (total, free, used)
    pub gpu_status: HashMap<GpuId, (u64, u64, u64)>,
    /// 请求到达速率，Model id -> 请求到达速率(100 reqs/s)
    pub workload_req: HashMap<ModelId, f32>,
    /// 未处理请求量，Model id -> 未处理请求量(100 reqs)
    pub workload: HashMap<ModelId, f32>,
    /// 工作负载等待时间，Model id -> 工作负载等待时间(ms)
    pub workload_wait_time: HashMap<ModelId, f32>,
}

/// Inss 调度器
#[derive(Debug)]
pub struct InssScheduler {
    /// 待调度模型数量, 影响inss model input dim
    pub model_nums: u32,

    /// 待调度GPU数量, 影响inss model input dim
    pub gpu_nums: u32,

    /// 调度环境
    pub environment: ScheduleEnvironment,

    /// 模型SLO, model name -> SLO (s)
    model_slo: HashMap<ModelName, f32>,

    /// 模型内存使用量 model name -> (gpu type -> (batch size -> memory cost))
    model_memory_cost: HashMap<ModelName, HashMap<GpuType, HashMap<BatchSize, f32>>>,

    /// 延迟预测器
    latency_predictor: LatencyPredictor,

    /// 使用强化学习的内部调度模型
    ///
    /// - input dim: `[model_num * 3 + GPU nums, 1]`
    ///     - model_num * 3：分别按顺序排列使用GPU资源百分比、预期工作负载到达速率(100 reqs/s)、模型放置位置
    ///     - GPU nums：分别放置对应位置GPU内存使用量
    ///     - 模型顺序和GPU顺序必须与预训练时一致，各数据单位也应当一致
    /// - output_dim: `[(gpu_num + resource_slice_num) * model_num, 1]`
    ///    - gpu_num: 每一位表示选择某个位置GPU的概率
    ///    - resource_slice_num: 每一位表示选择某个位置GPU的应当给予的资源片数的概率
    inference_model: TorchModel,
}

/// Schedule environment which will not change during the scheduling
#[derive(Debug, Clone, PartialEq)]
pub struct ScheduleEnvironment {
    /// 可供调度的GPU列表，内部存储GPU type
    pub gpu_type_list: Vec<GpuType>,
    /// 待调度模型列表，内部存储模型名称
    pub model_type_list: Vec<ModelName>,
    /// Nvidia MPS 资源分片数
    ///
    /// MPS 可设置0～100，但是仅会fallback到最接近的可用SM
    ///
    /// 例如，对于RTX 2060s，可以SM可以分为17份，每份对应资源量为6
    ///
    /// GPU type -> (每一份资源对应百分比，资源上限片数)
    pub resource_slice: HashMap<GpuType, (u32, u32)>,
}

/// Schedule config which contains all the information needed to init the scheduler
#[derive(Debug, Clone, PartialEq, Deserialize)]
pub struct ScheduleConfig<Path: AsRef<std::path::Path>> {
    /// Inss调度模型路径
    pub inss_path: Path,
    /// 延迟预测数据路径
    pub latency_predict_path: Path,
    /// 待调度模型
    pub models: Vec<ModelName>,
    /// 模型SLO
    pub model_slo: HashMap<ModelName, f32>,
    /// 模型内存使用量 model name -> (gpu type -> (batch size -> memory cost))
    pub model_memory_cost: HashMap<ModelName, HashMap<GpuType, HashMap<BatchSize, f32>>>,
    /// 可供调度GPU
    pub gpus: Vec<GpuType>,
    /// Nvidia MPS 资源分片数
    ///
    /// MPS 可设置0～100，但是仅会fallback到最接近的可用SM
    ///
    /// 例如，对于RTX 3060s，可以SM可以分为17份，每份对应资源量为6
    ///
    /// GPU type -> (每一份资源对应百分比，资源上限片数)
    pub resource_slice: HashMap<GpuType, (u32, u32)>,
}

impl<Path: AsRef<std::path::Path>> ScheduleConfig<Path>
where
    Path: DeserializeOwned,
{
    /// Load schedule config from file
    pub fn from_file(path: impl AsRef<std::path::Path>) -> Self {
        let file = std::fs::File::open(path.as_ref()).expect("Failed to open schedule config file");
        let reader = std::io::BufReader::new(file);
        let config: ScheduleConfig<Path> =
            serde_json::from_reader(reader).expect("Failed to parse schedule config file");
        config
    }
}

impl InssScheduler {
    /// Init scheduler from config
    pub fn init(config: ScheduleConfig<impl AsRef<Path>>) -> Self {
        let ScheduleConfig {
            inss_path,
            latency_predict_path,
            models,
            model_slo,
            model_memory_cost,
            gpus,
            resource_slice,
        } = config;

        let load_config = TorchModelLoadConfig::new(
            inss_path.as_ref().to_path_buf(),
            Device::Cpu,
            TensorElementType::Float,
            vec![(models.len() * 3 + gpus.len()) as i64],
            true,
        );

        let inference_model = TorchModel::load(load_config).expect("Failed to load Inss model");
        InssScheduler {
            model_nums: models.len() as u32,
            gpu_nums: gpus.len() as u32,
            environment: ScheduleEnvironment {
                gpu_type_list: gpus,
                model_type_list: models,
                resource_slice,
            },
            model_slo,
            model_memory_cost,
            latency_predictor: LatencyPredictor::from_file(latency_predict_path)
                .expect("Failed to load latency predictor"),
            inference_model,
        }
    }
}
