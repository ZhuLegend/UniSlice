//! impl [ComputeNode] for [InssComputeNode]

use std::{collections::HashMap, marker::PhantomData};

use compute_node::{
    ComputeNode,
    compute_device::nv::NvGpuResponse,
    compute_node::virtual_util::{ComputeNodeState, ComputeNodeStatus},
};
use serde::{Deserialize, Serialize};
use tracing::instrument;
use worker::model::tensor::DynTensor;

use crate::examples::{
    MsTimestamp,
    scheduler::{BatchSize, GpuId, ModelName},
    system::compute_node::{
        InssComputeNode,
        task::{AlreadyInferred, Task, TaskInfo, TaskState, WaitForInference},
        task_handler::TaskHandlerState,
    },
};

/// [InssComputeNode]'s [State]
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct State {
    /// ModelName -> (GpuId, percentage)
    pub model_placements: HashMap<ModelName, (GpuId, u32)>,
    /// ModelName -> batch size
    pub batch_size: HashMap<ModelName, BatchSize>,
}

/// [InssComputeNode]'s [Status]
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Status {
    /// GpuId -> (total, free, used)
    pub gpu_state: HashMap<GpuId, (u64, u64, u64)>,
    /// ModelName -> (wait queue length, max wait time (ms))
    pub buffer_state: HashMap<ModelName, (usize, MsTimestamp)>,
}

/// A task
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Work<State: TaskState> {
    model_name: ModelName,
    tensor: DynTensor,
    _state: PhantomData<fn() -> State>,
}

impl Work<WaitForInference> {
    /// Creates a new `Work` instance.
    pub fn new(model_name: ModelName, tensor: DynTensor) -> Self {
        Work {
            model_name,
            tensor,
            _state: PhantomData,
        }
    }
}

impl Work<WaitForInference> {
    #[allow(clippy::type_complexity)]
    fn to_task(
        self,
    ) -> (
        Task<WaitForInference>,
        tokio::sync::oneshot::Receiver<Result<(TaskInfo, DynTensor), String>>,
    ) {
        let (tx, rx) = tokio::sync::oneshot::channel();
        let Work {
            model_name,
            tensor,
            _state: _,
        } = self;

        (Task::<WaitForInference>::new(model_name, tensor, tx), rx)
    }
}

impl Work<AlreadyInferred> {
    /// Extracts the tensor from the work.
    pub fn extract_tensor(self) -> DynTensor {
        self.tensor
    }
}

/// [Command] used by InssComputeNode
#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum Command {
    /// Set the batch size for a specific model.
    SetBatchSize(ModelName, BatchSize),
    /// Set the batch size for all models.
    SetBatchSizeAll(BatchSize),
    /// Set model place for a specific model. (model name, gpu id, percentage)
    SetModelPlace(ModelName, GpuId, u32),
}

impl InssComputeNode {
    async fn query_state(&self) -> Result<State, String> {
        let ComputeNodeState { workers: _ } = self.inner.state().await?;

        let model_placements = self.inner.get_model_placements();

        let batch_size = self
            .batch_size_channels
            .iter()
            .map(|(model_name, (_, receiver))| {
                let batch_size = *receiver.borrow();
                (model_name.clone(), batch_size)
            })
            .collect();

        Ok(State {
            model_placements,
            batch_size,
        })
    }

    async fn query_status(&self) -> Result<Status, String> {
        let ComputeNodeStatus {
            worker_proxy_type: _,
            devices,
        } = self.inner.status().await?;
        let device_id = self.inner.device_id();
        let gpu_state = devices
            .into_iter()
            .map(|(gpu_id, res)| match res {
                NvGpuResponse::MemoryInfo { total, free, used } => {
                    (device_id[&gpu_id], (total, free, used))
                }
                NvGpuResponse::NvmlError(e) => {
                    panic!("Compute node returned NVML error: {e:?}")
                }
            })
            .collect();
        let buffer_state = self
            .task_handlers
            .iter()
            .map(|(model_name, handler)| {
                let TaskHandlerState {
                    wait_task_len,
                    max_wait_time,
                } = *handler.subscribe_state().borrow();
                (model_name.clone(), (wait_task_len, max_wait_time))
            })
            .collect();

        Ok(Status {
            gpu_state,
            buffer_state,
        })
    }

    async fn set_batch_size(
        &self,
        model_name: ModelName,
        batch_size: BatchSize,
    ) -> Result<(), String> {
        self.batch_size_channels
            .get(&model_name)
            .ok_or("Model not found")?
            .0
            .send_replace(batch_size);

        Ok(())
    }
}

impl ComputeNode for InssComputeNode {
    type State = State;
    type Status = Status;
    type Command = Command;

    type InputData = Work<WaitForInference>;

    type OutputData = Work<AlreadyInferred>;

    #[instrument(level = "trace", skip(self))]
    async fn handle(&self, command: Self::Command) -> Result<Self::State, String> {
        match command {
            Command::SetBatchSize(model_name, batch_size) => {
                self.set_batch_size(model_name, batch_size).await?;
            }
            Command::SetBatchSizeAll(batch_size) => {
                for (model_name, _) in self.batch_size_channels.iter() {
                    self.set_batch_size(model_name.clone(), batch_size).await?;
                }
            }
            Command::SetModelPlace(model_name, gpu_id, percentage) => {
                self.inner
                    .replace_model(model_name, gpu_id, percentage)
                    .await?;
            }
        }

        self.query_state().await
    }

    async fn state(&self) -> Result<Self::State, String> {
        self.query_state().await
    }

    async fn status(&self) -> Result<Self::Status, String> {
        self.query_status().await
    }

    async fn compute(&self, work: Self::InputData) -> Result<Self::OutputData, String> {
        let model_name = work.model_name.clone();
        let (task, receiver) = work.to_task();

        self.task_handlers
            .get(&model_name)
            .ok_or("Model not found")?
            .submit(task)
            .await?;

        let result = receiver.await.map_err(|e| format!("Receiver error: {e}"))?;

        match result {
            //TODO: log task info
            Ok((_task_info, tensor)) => Ok(Work::<AlreadyInferred> {
                model_name,
                tensor,
                _state: PhantomData,
            }),
            Err(e) => Err(e),
        }
    }
}
