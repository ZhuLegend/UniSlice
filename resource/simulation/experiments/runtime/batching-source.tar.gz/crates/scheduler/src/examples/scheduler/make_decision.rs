use std::collections::HashMap;

use ndarray::{Array, Axis, s};
use rand::prelude::SliceRandom;
use tracing::trace;
use worker::model::tensor::Tensor;

use crate::examples::scheduler::{GpuId, InssScheduler, ModelId, ResourceSlices, Status};

impl InssScheduler {
    /// 获取指定位置GPU的资源片数上限
    fn slices_limit(&self, gpu_id: usize) -> usize {
        let gpu_type = self
            .environment
            .gpu_type_list
            .get(gpu_id)
            .expect("GPU type not found");
        let (_, slice_limit) = self
            .environment
            .resource_slice
            .get(gpu_type)
            .expect("GPU type not found");
        *slice_limit as usize
    }

    /// 从调度计划中提取给每个GPU分配的模型
    ///
    /// # Arguments
    /// - gpu_nums: GPU数量
    /// - decision: 调度计划 model id -> (GPU id, resource slice)
    ///
    /// # Returns
    /// - GPU id -> (total resource slice, HashMap<model id, resource slice>)
    fn extract_gpu_slices(
        gpu_nums: usize,
        decision: &HashMap<usize, (usize, usize)>,
    ) -> HashMap<usize, (usize, HashMap<usize, usize>)> {
        decision.iter().fold(
            HashMap::with_capacity(gpu_nums),
            |mut acc, (model_id, (gpu_id, resource_slice))| {
                let gpu_id = *gpu_id;
                let resource_slice = *resource_slice;
                acc.entry(gpu_id).or_insert_with(|| (0, HashMap::new())).0 += resource_slice;
                acc.entry(gpu_id)
                    .or_insert_with(|| (0, HashMap::new()))
                    .1
                    .insert(*model_id, resource_slice);
                acc
            },
        )
    }

    /// 给予一组使用资源之和超出limit的模型列表，将这些模型列表打乱后，按序减少资源片数，直到最终消耗刚好为资源上限，减少模型使用片数时，不会少于1
    ///
    /// # Arguments
    /// - limit: 资源上限
    /// - curr_slice: 当前资源片数
    /// - scheduled_models: 需要调度的模型列表
    fn match_gpu_slices_limit(
        limit: usize,
        curr_slice: usize,
        scheduled_models: &mut [(&usize, &mut usize)],
    ) {
        scheduled_models.shuffle(&mut rand::rng());

        let mut total_slice = curr_slice;
        while total_slice > limit {
            for (_, resource_slice) in scheduled_models.iter_mut() {
                if total_slice > limit {
                    if *resource_slice > &mut 1 {
                        **resource_slice -= 1;
                        total_slice -= 1;
                    }
                } else {
                    break;
                }
            }
        }
    }
}

impl InssScheduler {
    /// 从系统状态中提取调度模型的输入数据
    ///
    /// 输入dim格式如下：
    /// - input dim: `[model_num * 3 + GPU nums, 1]`
    ///     - model_num * 3：分别按顺序排列工作负载到达速率(100 req/s)、当前未计算工作负载(100 reqs/s)、模型放置位置
    ///     - GPU nums：分别放置对应位置GPU内存使用量
    ///     - 模型顺序和GPU顺序必须与预训练时一致，各数据单位也应当一致
    ///
    /// # Arguments
    /// - status: 系统状态
    /// - state: 调度状态 model id -> GPU id
    ///
    /// # Returns
    /// - 调度模型输入数据
    pub fn extract_input_dim(
        &self,
        status: &Status,
        state: &HashMap<ModelId, GpuId>,
    ) -> Tensor<f32> {
        // 设置GPU内存使用率
        let gpu_memory_rate = status
            .gpu_status
            .values()
            .map(|memory_info| {
                let (total, _, used) = *memory_info;
                used as f32 / total as f32
            })
            .collect::<Vec<_>>();

        let mut input_dim = state
            .iter()
            .flat_map(|(model_id, gpu_id)| {
                let workload_req = *status
                    .workload_req
                    .get(model_id)
                    .expect("Model workload not found");
                let workload = *status
                    .workload
                    .get(model_id)
                    .expect("Model workload not found");
                [workload_req, workload, *gpu_id as f32]
            })
            .collect::<Vec<_>>();

        input_dim.extend(gpu_memory_rate);

        let array = Array::from_iter(input_dim).insert_axis(Axis(0));

        Tensor::from(array.into_dyn())
    }

    /// 从预测输出提取调度决策
    ///
    /// 预测输出数据格式如下：
    /// - output_dim size: `[1, (gpu_num + resource_slice_num) * model_num]`
    ///     - gpu_num: 每一位表示选择某个位置GPU的概率
    ///     - resource_slice_num: 每一位表示选择某个位置GPU的应当给予的资源片数的概率
    ///
    /// # Arguments
    /// - output: 调度模型输出
    ///
    /// # Returns
    /// - model id -> (GPU id, resource slice)
    pub fn parse_output_dim(
        &self,
        output: Tensor<f32>,
    ) -> HashMap<ModelId, (GpuId, ResourceSlices)> {
        output
            .data()
            .remove_axis(Axis(0))
            .axis_chunks_iter(
                Axis(0),
                (self.gpu_nums
                    + self
                        .environment
                        .resource_slice
                        .iter()
                        .max_by_key(|item| item.1)
                        .unwrap()
                        .1
                        .1) as usize,
            )
            .enumerate()
            .map(|(model_id, chunk)| {
                // 概率最大的position为GPU id/资源片数
                let gpu_id = chunk
                    .slice(s![..self.gpu_nums as usize])
                    .iter()
                    .enumerate()
                    .max_by(|(_, a), (_, b)| a.partial_cmp(b).unwrap())
                    .expect("No GPU id found")
                    .0;

                let resource_slice = chunk
                    .slice(s![self.gpu_nums as usize..])
                    .iter()
                    .enumerate()
                    .max_by(|(_, a), (_, b)| a.partial_cmp(b).unwrap())
                    .expect("No resource slice found")
                    .0;
                (model_id, (gpu_id, resource_slice))
            })
            .collect()
    }

    /// 获取可以满足GPU资源上限限制的调度决策
    ///
    /// # Arguments
    /// - unoptimized_decision: 调度决策 model id -> (GPU id, resource slice)
    ///
    /// # Returns
    /// - model id -> (GPU id, resource slice)
    pub fn get_possible_decision(
        &self,
        unoptimized_decision: &HashMap<ModelId, (GpuId, ResourceSlices)>,
    ) -> HashMap<ModelId, (GpuId, ResourceSlices)> {
        // GPU id -> (资源片数, Vec<model id>)
        let mut gpu_allocation =
            Self::extract_gpu_slices(self.gpu_nums as usize, unoptimized_decision);
        trace!("GPU allocation: {:?}", gpu_allocation);
        gpu_allocation
            .iter_mut()
            .for_each(|(gpu_id, (total_slice, scheduled_models))| {
                let limit = self.slices_limit(*gpu_id);

                if *total_slice > limit {
                    let mut scheduled_models = scheduled_models.iter_mut().collect::<Vec<_>>();
                    Self::match_gpu_slices_limit(
                        limit,
                        *total_slice,
                        scheduled_models.as_mut_slice(),
                    );
                }

                assert!(scheduled_models.values().cloned().sum::<usize>() <= limit);
            });

        gpu_allocation.into_iter().fold(
            HashMap::with_capacity(unoptimized_decision.len()),
            |mut acc, (gpu_id, (_, scheduled_models))| {
                scheduled_models
                    .into_iter()
                    .for_each(|(model_id, resource_slice)| {
                        acc.insert(model_id, (gpu_id, resource_slice));
                    });
                acc
            },
        )
    }
}
