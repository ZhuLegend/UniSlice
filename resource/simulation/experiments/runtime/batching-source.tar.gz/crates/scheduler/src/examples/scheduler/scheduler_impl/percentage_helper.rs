//! utils for inss

use std::cmp::min;

use super::super::{Percentage, ResourceSlices, ScheduleEnvironment};

impl ScheduleEnvironment {
    fn get_resource_slice(&self, gpu_type: impl AsRef<str>) -> (u32, u32) {
        *self
            .resource_slice
            .get(gpu_type.as_ref())
            .expect("GPU type not found")
    }

    /// Convert percentage to resource slices
    pub fn percentage_to_slices(
        &self,
        gpu_type: impl AsRef<str>,
        percentage: Percentage,
    ) -> ResourceSlices {
        assert!(percentage <= 100);
        let (percentage_pre_slice, max_slices) = self.get_resource_slice(gpu_type);
        if percentage == 100 {
            max_slices as ResourceSlices
        } else {
            (percentage / percentage_pre_slice) as ResourceSlices
        }
    }

    /// Convert resource slices to percentage
    pub fn slice_to_percentage(
        &self,
        gpu_type: impl AsRef<str>,
        slice: ResourceSlices,
    ) -> Percentage {
        let (percentage_pre_slice, _) = self.get_resource_slice(gpu_type);
        min((slice * percentage_pre_slice as usize) as Percentage, 100)
    }
}
