use std::collections::HashMap;

use serde::{Deserialize, Serialize};

use super::super::scheduler::{GpuId, ModelName, Percentage};

/// system config
#[derive(Debug, Serialize, Deserialize)]
pub struct Config {
    /// model name -> req rate
    pub workload_req: HashMap<ModelName, f64>,
    /// model name -> batch size
    pub batch_size: HashMap<ModelName, usize>,
    /// model name -> (target gpu id, target percentage)
    pub model_placement: HashMap<ModelName, (GpuId, Percentage)>,
}

impl Config {
    /// Create [Config] from file
    #[tracing::instrument(level = "debug", skip(path))]
    pub fn from_file(path: impl AsRef<std::path::Path>) -> Result<Self, String> {
        let file = std::fs::File::open(path).map_err(|e| e.to_string())?;
        let reader = std::io::BufReader::new(file);
        serde_json::from_reader(reader).map_err(|e| e.to_string())
    }
}
