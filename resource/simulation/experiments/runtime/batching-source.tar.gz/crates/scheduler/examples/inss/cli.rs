use std::{collections::HashSet, path::PathBuf};

use clap::Parser;

#[derive(Debug, Parser)]
#[command(name = "Inss GPU cluster inference schedule system")]
#[command(version = "1.0")]
#[command(about = "A GPU cluster inference schedule system using Inss schedule policy")]
pub struct Cli {
    /// GPU ids to use
    pub gpus: String,

    /// System config
    #[arg(long, value_name = "FILE", env = "SYSTEM_CONFIG", value_hint = clap::ValueHint::FilePath)]
    pub system_config: PathBuf,
    /// Path to the model directory
    #[arg(long, value_name = "DIR_PATH", env = "MODEL_DIR", value_hint = clap::ValueHint::DirPath)]
    pub model_dir: PathBuf,
    /// Path to the model configs path
    #[arg(long, value_name = "DIR_PATH", env = "MODEL_CONFIG_DIR", value_hint = clap::ValueHint::DirPath)]
    pub model_config_dir: PathBuf,
    /// Path to the bin worker path
    pub bin_worker_path: PathBuf,
    /// Path to the Schedule config json path
    #[arg(long, value_name = "FILE", env = "SCHEDULE_CONFIG", value_hint = clap::ValueHint::FilePath)]
    pub schedule_config: PathBuf,
    /// listening address
    #[arg(short, long, value_name = "PORT", value_parser = clap::value_parser!(u16).range(1..))]
    pub port: u16,
}

pub fn parse_range(s: &str) -> Result<Vec<usize>, String> {
    let mut result = HashSet::new();
    for part in s.split(',') {
        if part.contains("..") {
            // 处理范围（如 1..4）
            let range_parts: Vec<&str> = part.split("..").collect();
            if range_parts.len() != 2 {
                return Err(format!("无效范围格式: '{part}'"));
            }
            let start = range_parts[0]
                .parse::<usize>()
                .map_err(|_| format!("无效起始数字: '{}'", range_parts[0]))?;
            let end = range_parts[1]
                .parse::<usize>()
                .map_err(|_| format!("无效结束数字: '{}'", range_parts[1]))?;
            if start > end {
                return Err(format!("范围起始值不能大于结束值: '{part}'"));
            }
            result.extend(start..=end);
        } else {
            // 处理单个数字（如 7）
            let num = part
                .parse::<usize>()
                .map_err(|_| format!("无效数字: '{part}'"))?;
            result.insert(num);
        }
    }

    let result = {
        let mut res = result.into_iter().collect::<Vec<_>>();
        res.sort();
        res
    };

    Ok(result)
}
