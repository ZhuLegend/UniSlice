//! Inss implementation of the scheduler

#![warn(missing_docs)]

use std::path::PathBuf;

use ::scheduler::examples::{scheduler::ScheduleConfig, system::compute_node::InssComputeNode};
use clap::Parser;
use cli::Cli;
use comm::{Listener, TypedConnection, connection::ConnectionBuilder};
use scheduler::examples::{scheduler::ModelName, system, system::System};
use tokio::net::TcpListener;
use tracing::error;
use tracing_subscriber::EnvFilter;
use worker::model::tensor::DynTensor;

mod cli;

#[tokio::main]
async fn main() {
    tracing_subscriber::fmt()
        .with_env_filter(EnvFilter::from_default_env())
        .init();

    let cli = Cli::parse();
    let gpus = cli::parse_range(&cli.gpus).unwrap_or_else(|err| {
        error!("Failed to parse GPUs: {:#?}", err);
        std::process::exit(1);
    });

    let system_config =
        system::Config::from_file(cli.system_config).expect("Unable to load system config");

    let compute_node = InssComputeNode::new(
        gpus,
        cli.model_dir,
        cli.model_config_dir,
        cli.bin_worker_path,
        system_config.batch_size,
        system_config.model_placement,
    );

    let schedule_config: ScheduleConfig<PathBuf> = ScheduleConfig::from_file(&cli.schedule_config);
    let scheduler = scheduler::examples::scheduler::InssScheduler::init(schedule_config);
    let compute_node = compute_node.await.expect("Unable to create compute node");

    let system = System::new(scheduler, compute_node, system_config.workload_req);

    let tcp_listener = TcpListener::bind(format!("0.0.0.0:{}", cli.port))
        .await
        .expect("Unable to start tcp listener");

    system
        .listen(utils::sync::Task::new(), tcp_listener, |stream, _| {
            ConnectionBuilder::new_io(stream).build::<TypedConnection<
                _,
                Option<DynTensor>,
                (ModelName, DynTensor),
            >>()
        })
        .await;
}
