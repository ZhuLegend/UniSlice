use std::{collections::HashMap, io::BufReader, path::Path};

use scheduler::examples::scheduler::ModelName;
use serde::{Deserialize, Serialize};

#[derive(Debug, Serialize, Deserialize)]
pub(crate) struct Config {
    /// request rate change interval in ms
    pub(crate) req_change_interval: usize,
    /// model name -> (req lower, req upper)
    pub(crate) model_req: HashMap<ModelName, (usize, usize)>,
}

impl Config {
    pub(crate) fn from_file(path: impl AsRef<Path>) -> Self {
        serde_json::from_reader(BufReader::new(std::fs::File::open(path).unwrap())).unwrap()
    }
}
