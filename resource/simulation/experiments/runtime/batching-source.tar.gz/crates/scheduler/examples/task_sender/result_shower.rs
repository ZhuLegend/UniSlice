use indicatif::ProgressBar;
use scheduler::examples::scheduler::{BatchSize, ModelName};

pub(crate) struct ResultShower {
    indicator: ProgressBar,
    _handle: tokio::task::JoinHandle<()>,
    token: tokio_util::sync::CancellationToken,
}

impl ResultShower {
    pub(crate) fn new(mut rx: tokio::sync::mpsc::Receiver<(ModelName, BatchSize, usize)>) -> Self {
        let indicator = ProgressBar::new_spinner();
        indicator.set_style(
            indicatif::ProgressStyle::default_spinner()
                .template("{spinner} {wide_msg} {elapsed} ({per_sec})")
                .unwrap(),
        );
        indicator.enable_steady_tick(std::time::Duration::from_millis(100));
        indicator.set_message("Start to sending task...");

        let token = tokio_util::sync::CancellationToken::new();

        let _handle = tokio::spawn({
            let indicator = indicator.clone();
            let token = token.clone();
            async move {
                let mut average_cost = 0u64;
                let mut max_slo = 0u64;
                while let Some((model_name, batch_size, cost)) = rx.recv().await {
                    if token.is_cancelled() {
                        break;
                    }
                    indicator.inc(batch_size as u64);
                    indicator.println(format!(
                        "Model: {model_name}, Batch size: {batch_size}, Cost: {cost} ms"
                    ));
                    average_cost =
                        (average_cost as f64 * 0.6 + cost as f64 * 0.4 / batch_size as f64) as u64;
                    max_slo = (max_slo as f64 * 0.6 + cost as f64 * 0.4) as u64;
                    indicator.set_message(format!(
                        "Model: {model_name}, Average cost: {average_cost}, Max slo: {max_slo}"
                    ));
                }
            }
        });

        Self {
            indicator,
            _handle,
            token,
        }
    }

    pub(crate) fn progress_bar(&self) -> ProgressBar {
        self.indicator.clone()
    }
}

impl Drop for ResultShower {
    fn drop(&mut self) {
        self.token.cancel();
        self.indicator.finish_and_clear();
    }
}
