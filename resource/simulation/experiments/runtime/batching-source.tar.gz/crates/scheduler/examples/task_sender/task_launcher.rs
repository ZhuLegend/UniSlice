use std::time::Duration;

use comm::{CommChannel, TypedConnection, connection::ConnectionBuilder, service::Service};
use futures::future::JoinAll;
use scheduler::examples::scheduler::{BatchSize, ModelName};
use worker::model::tensor::DynTensor;

pub(crate) struct TaskLauncher {
    _handle: tokio::task::JoinHandle<()>,
    token: tokio_util::sync::CancellationToken,
}

impl Drop for TaskLauncher {
    fn drop(&mut self) {
        self.token.cancel();
    }
}

impl TaskLauncher {
    async fn send_task(
        model_name: ModelName,
        tensor: DynTensor,
        mut conn: TypedConnection<impl Service, (ModelName, DynTensor), Option<DynTensor>>,
        result_updater: tokio::sync::mpsc::Sender<(ModelName, BatchSize, usize)>,
    ) {
        let batch_size = tensor.dimensions()[0] as BatchSize;
        conn.send(&(model_name.clone(), tensor))
            .await
            .unwrap_or_else(|e| {
                panic!("Failed to send task: {e:?}");
            });
        let instant = tokio::time::Instant::now();
        let result = conn.recv().await.unwrap().flatten();
        let duration = instant.elapsed();
        if result.is_none() {
            println!("Task failed");
        }
        result_updater
            .send((model_name, batch_size, duration.as_millis() as usize))
            .await
            .unwrap();
    }

    fn launch_task(
        model_name: ModelName,
        batch_size: BatchSize,
        connect: TypedConnection<
            impl Service + Sync + 'static,
            (ModelName, DynTensor),
            Option<DynTensor>,
        >,
        tensor_getter: impl Fn(BatchSize) -> DynTensor + Send + 'static,
        result_updater: tokio::sync::mpsc::Sender<(ModelName, BatchSize, usize)>,
    ) -> impl Future<Output = ()> + Send + 'static {
        let tensor = tensor_getter(batch_size as BatchSize);

        let model_name = model_name.clone();
        let result_updater = result_updater.clone();
        async move {
            Self::send_task(model_name, tensor, connect, result_updater.clone()).await;
        }
    }

    pub(crate) fn new(
        compute_node_addr: String,
        model_name: ModelName,
        target_req: tokio::sync::watch::Receiver<usize>,
        result_updater: tokio::sync::mpsc::Sender<(ModelName, BatchSize, usize)>,
        tensor_getter: impl Fn(BatchSize) -> DynTensor + Clone + Send + 'static,
    ) -> Self {
        let connect = async move || {
            ConnectionBuilder::connect(compute_node_addr)
                .await
                .unwrap_or_else(|e| {
                    panic!("Failed to connect to compute node: {e:?}");
                })
                .build()
        };
        let token = tokio_util::sync::CancellationToken::new();

        let _handle = tokio::spawn({
            let token = token.clone();
            let mut interval = tokio::time::interval(Duration::from_secs(1));
            async move {
                loop {
                    tokio::select! {
                        _ = token.cancelled() => break,
                        _ = interval.tick() => {}
                    }
                    let mut total_req = *target_req.borrow();
                    tokio::spawn({
                        let connect = connect.clone();
                        let tensor_getter = tensor_getter.clone();
                        let result_updater = result_updater.clone();
                        let model_name = model_name.clone();
                        async move {
                            let mut vec = Vec::with_capacity(total_req / 32 + 1);
                            while total_req > 32 {
                                let batch = rand::random::<u32>() % 32 + 1;
                                total_req -= batch as usize;
                                vec.push(Self::launch_task(
                                    model_name.clone(),
                                    batch as BatchSize,
                                    connect.clone()().await,
                                    tensor_getter.clone(),
                                    result_updater.clone(),
                                ));
                            }
                            vec.push(Self::launch_task(
                                model_name,
                                total_req as BatchSize,
                                connect().await,
                                tensor_getter,
                                result_updater,
                            ));
                            vec.into_iter().collect::<JoinAll<_>>().await
                        }
                    });
                }
            }
        });

        Self { _handle, token }
    }
}
