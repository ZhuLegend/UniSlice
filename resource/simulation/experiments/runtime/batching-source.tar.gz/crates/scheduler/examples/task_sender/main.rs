use std::{collections::HashMap, path::PathBuf};

use clap::Parser;
use scheduler::examples::scheduler::{BatchSize, ModelName};
use tokio::signal::unix::{SignalKind, signal};
use tracing_subscriber::EnvFilter;
use worker::model::tensor::DynTensor;

use crate::config::Config;

mod config;
mod load_image;
mod req_updater;
mod result_shower;
mod task_launcher;

#[derive(Parser, Debug)]
struct Cli {
    /// Path to the image which will used as task data
    image_path: PathBuf,
    /// Path to the config file
    #[arg(long)]
    config: PathBuf,
    /// IP address of the compute node
    #[arg(long, default_value_t = ("127.0.0.1".to_string()))]
    ip: String,
    #[arg(short, long)]
    port: u16,
}

#[tokio::main]
async fn main() {
    tracing_subscriber::fmt()
        .with_env_filter(EnvFilter::from_default_env())
        .init();

    let cli = Cli::parse();
    let Config {
        req_change_interval,
        model_req,
    } = Config::from_file(cli.config);
    let image_path = cli.image_path;
    let multi_progress = indicatif::MultiProgress::new();
    let (_model_req_updaters, _model_task_launcher, _model_result_shower) = model_req
        .iter()
        .map(|(model_name, (lower, upper))| {
            let (tx, rx) = tokio::sync::watch::channel(*lower);
            let req_updater = req_updater::ReqUpdater::new(*lower, *upper, req_change_interval, tx);
            (model_name.clone(), (req_updater, rx))
        })
        .fold(
            (
                HashMap::with_capacity(model_req.len()),
                HashMap::with_capacity(model_req.len()),
                HashMap::with_capacity(model_req.len()),
            ),
            |(mut model_req_updaters, mut model_task_launcher, mut model_result_shower),
             (model_name, (req_updater, rx))| {
                model_req_updaters.insert(model_name.clone(), req_updater);
                let (result_tx, result_rx) =
                    tokio::sync::mpsc::channel::<(ModelName, BatchSize, usize)>(500);
                let path = image_path.clone();
                model_task_launcher.insert(
                    model_name.clone(),
                    task_launcher::TaskLauncher::new(
                        format!("{}:{}", cli.ip, cli.port),
                        model_name.clone(),
                        rx,
                        result_tx,
                        move |batch_size| {
                            let path = path.clone();
                            DynTensor::from(load_image::get_task_tensor(path, batch_size))
                        },
                    ),
                );
                let result_shower = result_shower::ResultShower::new(result_rx);
                let progress_bar = result_shower.progress_bar();
                multi_progress.add(progress_bar);
                model_result_shower.insert(model_name.clone(), result_shower);
                (model_req_updaters, model_task_launcher, model_result_shower)
            },
        );

    let mut sigint = signal(SignalKind::interrupt()).unwrap();
    let mut sigterm = signal(SignalKind::terminate()).unwrap();

    tokio::select! {
        _ = sigint.recv() => {
            println!("收到 SIGINT 信号，程序即将退出...");
        }
        _ = sigterm.recv() => {
            println!("收到 SIGTERM 信号，程序即将退出...");
        }
        _ = tokio::signal::ctrl_c() => {
            println!("收到 Ctrl+C 信号，程序即将退出...");
        }
    }
}
