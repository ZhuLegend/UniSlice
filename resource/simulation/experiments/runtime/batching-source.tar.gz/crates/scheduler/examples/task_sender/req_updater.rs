pub(crate) struct ReqUpdater {
    _handle: tokio::task::JoinHandle<()>,
    token: tokio_util::sync::CancellationToken,
}

impl Drop for ReqUpdater {
    fn drop(&mut self) {
        self.token.cancel();
    }
}

impl ReqUpdater {
    pub(crate) fn new(
        lower: usize,
        upper: usize,
        interval: usize,
        sender: tokio::sync::watch::Sender<usize>,
    ) -> Self {
        let token = tokio_util::sync::CancellationToken::new();
        let _handle = tokio::spawn({
            let token = token.clone();
            async move {
                let mut interval =
                    tokio::time::interval(tokio::time::Duration::from_millis(interval as u64));
                let mut req = lower;
                let mut inc_flag = true;
                loop {
                    tokio::select! {
                        _ = token.cancelled() => break,
                        _ = interval.tick() => {
                            if inc_flag {
                                req += 1;
                            } else {
                                req -= 1;
                            }
                            if req > upper {
                                req = upper;
                                inc_flag = false;
                            } else if req < lower {
                                req = lower;
                                inc_flag = true;
                            }
                            sender.send_replace(req);
                        }
                    }
                }
            }
        });
        Self { _handle, token }
    }
}
