use std::{
    path::Path,
    sync::{Mutex, OnceLock},
};

use scheduler::examples::scheduler::BatchSize;
use tch::vision::imagenet::load_image_and_resize224;

fn load_image(path: impl AsRef<Path>) -> tch::Tensor {
    load_image_and_resize224(path).unwrap().unsqueeze(0)
}

fn repeat_tensor(t: &tch::Tensor, n: i64) -> tch::Tensor {
    let shape_len = t.size().len();

    t.repeat(
        std::iter::once(n)
            .chain(std::iter::repeat_n(1, shape_len - 1))
            .collect::<Vec<_>>(),
    )
}

pub(crate) fn get_task_tensor(image_path: impl AsRef<Path>, batch_size: BatchSize) -> tch::Tensor {
    static IMAGE_CACHE: OnceLock<Mutex<Option<tch::Tensor>>> = OnceLock::new();

    let image_cache = IMAGE_CACHE.get_or_init(|| Mutex::new(None));
    let mut image_cache = image_cache.lock().unwrap();

    if let Some(tensor) = &*image_cache {
        return repeat_tensor(tensor, batch_size as i64);
    }

    let tensor = load_image(image_path);
    *image_cache = Some(tensor.shallow_clone());
    repeat_tensor(image_cache.as_ref().unwrap(), batch_size as i64)
}
